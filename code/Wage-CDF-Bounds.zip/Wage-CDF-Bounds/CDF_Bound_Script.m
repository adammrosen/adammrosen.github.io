% CDF_Bound_Script.m

% --------- DESCRIPTION --------------------------------------------------
% Executing this script produces the first panel of each of Figures 1 and 2
% in Ho and Rosen (2016): Partial Identification in Applied Research:
% Benefits and Challenges. The paper is available on-line at
% https://www.ifs.org.uk/uploads/cemmap/wps/cwp451616.pdf
% See Section 6.2, pages 34-38 for details regarding the illustrated
% bounds.
%
% See also the code comments of the function
% AnalyticBoundsProbSelectionWC.m for a description of output variables
% that store values of the corresponding CDF bounds.
%-------------------------------------------------------------------------

% Load Data in vectors log_WklyWage, YearsWorked, YearsEducation, HusbandAnWage, HHAssets, KidsUnder6, D
load NLSW1967_Heck76_clean;

% Set XZ exogenous variables as in Heckman '76 Table 3
XZ = [YearsWorked YearsEducation HusbandAnWage HHAssets KidsUnder6];

% Load the parameter values beta0,beta1,beta2,gamma0,gamma1,gamma2
% These are the values obtained using the Heckman command in Stata.
% We use these parameters as "true" population values for illustration
load param_vals;

% Set a grid of values at which to compute the wage CDF and wage CDF bounds
w_values = -0.5:0.1:1.5;

% Set XZsupport
% This can be set to whatever values we like, observed in the data or not.
% Here we just use the values of XZ that occur in the first 400 observations.
% Note that increasing the support of XZ by introducing more values of Z
% at a given x will tighten (or at least surely not reduce) conditional on
% x IV bounds.

% This code ensures we have the same support of Z for each
% (X1,X2) combination considered
EduIndices = (XZ(:,2)==12);   %find just elements of XZ where YearsEducn = 12, all experience values
XZ_Edu = XZ(EduIndices,:);    %this has 1145 rows
XZ_Edu = XZ_Edu(1:400,:);     %pulls out the first 400 XZ values in the data where YearsEducn=12.
                              %Will use these 400 Z combinations for every (X1,X2)
YearsWorkedSupport = [0;1;2;3;4;5]; %Set support for Years Worked

XZsupport = kron(ones(size(YearsWorkedSupport,1),1),XZ_Edu);   %repeats the block of 400 Z combinations 6 times vertically
XZsupport(:,1) = kron(YearsWorkedSupport, ones(400,1));  %replaces first column with 400 0's, then 400 1's, ...

% Uncomment these lines to increase support of Z as done in panels 2-4
% of Figure 2 in Ho and Rosen (2016).
%XZsupport = [XZsupport; [XZsupport(:,1:2) 2*(XZsupport(:,3:5))]];
%XZsupport = [XZsupport; [XZsupport(:,1:2) 3*(XZsupport(:,3:5))]];
%XZsupport = [XZsupport; [XZsupport(:,1:2) 4*(XZsupport(:,3:5))]];

% Compute analytic CDF and CDF bounds.
% See AnalyticBoundsProbSelectionWC.m for details.
[LB,UB,LB_IV,UB_IV,Xsupport,w_by_xz_CDF_values] = AnalyticBoundsProbSelectionWC(XZsupport,beta0,beta1,beta2,gamma0,gamma1,gamma2,sigma,rho,w_values);

%Look at 89th obs with the relevant years worked: 400*t+89 for t years
%89th obs has Z = (8000,12600,1), not far from overall mean (7444,17503,1)

%overall median (7500, 10250, 1)
index = 400*3+89;

%use this line instead of the previous to produce the 2nd panel of Figure 1.
%index = 400*3+5; 
%    
%index = 16; %54; % First observation with x corresponding to Years worked = 0 and Years education = 12.

% Plot the population wage CDF in blue, the worst case bounds for (x,z) as
% specified in observation *index*, and the IV bounds for the corresponding
% x, which is (0,12) for yrs work and education at observation 54.
plot(w_values,w_by_xz_CDF_values(index,:),'b',w_values,UB_IV(:,index),'r',w_values,LB_IV(:,index),'r',w_values,UB(:,index),'g',w_values,LB(:,index),'g');

