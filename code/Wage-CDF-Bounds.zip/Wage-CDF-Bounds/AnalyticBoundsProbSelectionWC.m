% AnalyticBoundsProbSelectionWC.m
% Compute worst-case and IV upper and lower bounds when the actual
% DGP follows a probit selection model as described in Section 6 of Ho
% and Rosen (2016): "Partial Identification in Applied Research: Benefits and Challenges".

% Kx1 is used to denote the dimension of X1
% Kz is used to denote the dimension of Z, etc.

% For example usage see the commands in CDF_Bound_Script.m
% Execute 'CDF_Bound_Script' to generate the figure WageCDFbounds_0_12.pdf

% --------- INPUT PARAMETERS ---------------------------------------------
% XZsupport: A Dxz * (Kx1+Kx2+Kz) matrix indicating Dxz support points for
%            the exogenous variables (x1,x2,z).
% beta0:     Intercept of wage equation.
% beta1:     A Kx1*1 parameter coefficient vector for wage covariates excluded from the
%            selection equation.
% beta2:     A Kx2*1 parameter coefficient vector for wage covariates included in the
%            selection equation.
% gamma0:    Intercept of selection equation.
% gamma1:    A Kz*1 parameter coefficient vector for instruments affecting
%            selection that are excluded from the determination of wages.
% gamma2:    A Kx2*1 parameter coefficient vector for covariates affecting
%            wages that are also allowed to affect selection.
% sigma:     The standard deviation of the unobservable in the wage equation.
% rho:       The correlation coefficient of the wage and selection
%            unobservables U1 and U2.
% w_values:  A 1*n_w_values row vector of values at which to bound the wage
%            CDF. Also to use for plotting

% --------- OUTPUT PARAMETERS ---------------------------------------------
% LB:       An n_w_values*Dxz matrix of worst case lower bounds on the wage CDF
%           Rows correspond to the values of w in w_values at which the CDF is
%           considered.  Columns correspond to support points for (X,Z).
% UB:       An n_w_values*Dxz matrix of worst case upper bounds on the wage CDF
% LB_IV:    An n_w_values*Dxz matrix of IV lower bounds on the wage CDF.
% UB_IV:    An n_w_values*Dxz matrix of IV upper bounds on the wage CDF.
%    NOTE: The IV upper and lower bounds corresponding to the same x values
%    but different z will be identical.
% Xsupport: The support of X obtained from the input matrix XZsupport.
% w_by_xz_CDF_values: The actual values of the wage CDF in the probit
%                    selection model with the given input parameter values.
%                    Dxz*n_w_values.

function [LB,UB,LB_IV,UB_IV,Xsupport,w_by_xz_CDF_values] = AnalyticBoundsProbSelectionWC(XZsupport,beta0,beta1,beta2,gamma0,gamma1,gamma2,sigma,rho,w_values)

Dxz = size(XZsupport,1); % Number of values on the support of (X1,X2,Z)
Kx1 = size(beta1,1); % Number of variables in X1
Kx2 = size(beta2,1); % Number of variables in X2
Kx = Kx1 + Kx2; % Number of variables in X = (X1,X2)
Kz = size(XZsupport,2) - Kx1 - Kx2; % Number of variables in Z

n_w_values = size(w_values,2);

WC_lower = zeros(n_w_values,Dxz);
WC_upper = zeros(n_w_values,Dxz);

Xbeta = beta0 + XZsupport(:,1:Kx) * [beta1;beta2];
X2gamma2_plus_Zgamma1 = gamma0 + XZsupport(:,(Kx1+1):(Kx+Kz)) * [gamma2;gamma1];
Pxz = normcdf(X2gamma2_plus_Zgamma1);

for i=1:Dxz
  w_count = 0;
  for w = w_values
    w_count = w_count+1;
    fun = @(t) integrand(w,Xbeta(i,1),sigma,rho,t); % integral appearing in middle of page 34.
    WC_lower(w_count,i) = integral(fun,-(X2gamma2_plus_Zgamma1(i,1)),inf); 
    WC_upper(w_count,i) = WC_lower(w_count,i) + 1-Pxz(i,1);
  end
end

LB = WC_lower;
UB = WC_upper;

Xsupport = unique(XZsupport(:,1:Kx),'rows');
Dx = size(Xsupport,1);

LB_IV = zeros(w_count,Dxz);
UB_IV = ones(w_count,Dxz);

% Find the max and min bounds for each x1,x2 combo, for each w in w_values.
% Also compute the true wage CDF values implied by the probit selection model. 
for i=1:Dxz
   Xval = XZsupport(i,1:Kx);
   for j=1:Dxz
     if isequal(Xval,XZsupport(j,1:Kx))
       LB_IV(:,i) = max(LB_IV(:,i),WC_lower(:,j));
       UB_IV(:,i) = min(UB_IV(:,i),WC_upper(:,j));
     end
   end
end

w_by_xz_CDF_values = normcdf((repmat(w_values,Dxz,1) - repmat(Xbeta,1,n_w_values))/sigma);

end

function val = integrand(w,xbeta,sigma1,rho,t)
  val = normcdf((w-xbeta-sigma1*rho*t)/(sigma1*sqrt(1-rho^2))).*normpdf(t);
end

